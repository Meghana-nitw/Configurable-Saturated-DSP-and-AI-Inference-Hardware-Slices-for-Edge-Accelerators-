`timescale 1ns/1ps

module tb_top;
    reg clk;
    reg rst_n;

    // Saturated DSP Pins
    reg [2:0] dsp_opcode;
    reg signed [15:0] dsp_A, dsp_B, dsp_C;
    wire signed [31:0] dsp_out;

    // Saturated AI Pins
    reg [1:0] ai_opcode;
    reg signed [15:0] ai_in0, ai_in1, ai_in2, ai_in3;
    reg signed [15:0] ai_w0,  ai_w1,  ai_w2,  ai_w3;
    reg signed [15:0] ai_scale, ai_bias;
    wire signed [31:0] ai_out;

    // UUT Block Allocations
    dsp_slice u_dsp_inst (
        .clk(clk), .rst_n(rst_n), .opcode(dsp_opcode),
        .A(dsp_A), .B(dsp_B), .C(dsp_C), .Out(dsp_out)
    );

    ai_slice u_ai_inst (
        .clk(clk), .rst_n(rst_n), .opcode(ai_opcode),
        .in0(ai_in0), .in1(ai_in1), .in2(ai_in2), .in3(ai_in3),
        .w0(ai_w0),   .w1(ai_w1),   .w2(ai_w2),   .w3(ai_w3),
        .bn_scale(ai_scale), .bn_bias(ai_bias), .Out(ai_out)
    );

    // Continuous 50MHz Clock Drive Generation
    always #10 clk = ~clk;

    initial begin
        // Signal Resets
        clk = 0; rst_n = 0;
        dsp_opcode = 3'b000; dsp_A = 0; dsp_B = 0; dsp_C = 0;
        ai_opcode = 2'b00; ai_in0 = 0; ai_in1 = 0; ai_in2 = 0; ai_in3 = 0;
        ai_w0 = 0; ai_w1 = 0; ai_w2 = 0; ai_w3 = 0; ai_scale = 0; ai_bias = 0;

        #25 rst_n = 1; #15;

        // ==========================================
        // EXHAUSTIVE DSP TEST ENGINE RUNS
        // ==========================================
        // Op 000: Multi-Input Addition (100 + 200 + 300 = 600)
        dsp_A = 16'd100; dsp_B = 16'd200; dsp_C = 16'd300; dsp_opcode = 3'b000; #20;
        
        // Op 001: Multi-Input Subtraction (1000 - 400 - 100 = 500)
        dsp_A = 16'd1000; dsp_B = 16'd400; dsp_C = 16'd100; dsp_opcode = 3'b001; #20;
        
        // Op 010: Vector Multiplication (-25 * 4 = -100)
        dsp_A = -16'd25; dsp_B = 16'd4; dsp_opcode = 3'b010; #20;
        
        // Op 011: MAC Pipeline Sequential Accumulations
        dsp_opcode = 3'b011; dsp_A = 16'd5; dsp_B = 16'd6; #20; // 30 -> Acc
        dsp_A = 16'd10; dsp_B = 16'd2; #20;                    // 20 -> 30 + 20 = 50
        
        // Op 100: Arithmetic Accumulator Stream Loops
        dsp_opcode = 3'b100; dsp_A = 16'd15; #20; dsp_A = 16'd35; #20;
        
        // Op 101: Combined Matrix Row Dot Product [(8*10) + (2*10) = 100]
        dsp_A = 16'd8; dsp_B = 16'd10; dsp_C = 16'd2; dsp_opcode = 3'b101; #20;
        
        // Op 110: Shift Engine Barrel Scale (A<<4 + B>>>2) -> (16<<4 + 40>>>2) = 256 + 10 = 266
        dsp_A = 16'd16; dsp_B = 16'd40; dsp_opcode = 3'b110; #20;
        
        // Op 111: Bitwise Logics (A^B | C)
        dsp_A = 16'h00FF; dsp_B = 16'h0F0F; dsp_C = 16'hF000; dsp_opcode = 3'b111; #20;

        // ==========================================
        // EXHAUSTIVE AI TEST ENGINE RUNS
        // ==========================================
        // Setup base data matrices
        ai_in0 = 16'd10; ai_in1 = 16'd20; ai_in2 = -16'd30; ai_in3 = 16'd40;
        ai_w0  = 16'd2;  ai_w1  = 16'd1;  ai_w2  = 16'd0;   ai_w3  = -16'd1;
        
        // Op 00: Conv1D System [(10*2)+(20*1)+(-30*0)+(40*-1) = 20 + 20 + 0 - 40 = 0]
        ai_opcode = 2'b00; #20;
        
        // Op 01: Max Pooling Filter Engine ([10, 20, -30, 40] -> Expected Max: 40)
        ai_opcode = 2'b01; #20;
        
        // Op 10: Average Pooling Engine Array ([10 + 20 - 30 + 40 = 40] -> 40 / 4 = 10)
        ai_opcode = 2'b10; #20;
        
        // Op 11: Normalization Path Alpha (LeakyReLU on negative element: in0 = -16 -> Output = -2)
        ai_scale = 16'h0; ai_bias = 16'h0; ai_in0 = -16'd16; ai_opcode = 2'b11; #20;
        
        // Op 11: Normalization Path Beta (Batch Normalization Mode: in0 = 5 * scale=2 + bias=1000 = 1010)
        ai_in0 = 16'd5; ai_scale = 16'd2; ai_bias = 16'd1000; ai_opcode = 2'b11; #20;

        $finish;
    end
endmodule
