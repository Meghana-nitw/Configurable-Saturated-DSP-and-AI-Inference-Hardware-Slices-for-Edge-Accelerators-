`timescale 1ns/1ps

module dsp_slice (
    input clk,
    input rst_n,
    input [2:0] opcode,          // 000 to 111 (8 Operations)
    input signed [15:0] A,
    input signed [15:0] B,
    input signed [15:0] C,       // Auxiliary input operand
    output reg signed [31:0] Out
);

    // Internal architectural tracking registers
    reg signed [31:0] pipe_mul;
    reg signed [31:0] accum_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pipe_mul  <= 32'h0;
            accum_reg <= 32'h0;
            Out       <= 32'h0;
        end else begin
            // Pipeline multiplier stage to mimic true ASIC slices
            pipe_mul <= A * B;

            case (opcode)
                3'b000: Out <= A + B + C;                      // 1. Multi-input Addition
                3'b001: Out <= A - B - C;                      // 2. Multi-input Subtraction
                3'b010: Out <= A * B;                          // 3. Vector Element Multiplication
                3'b011: Out <= pipe_mul + Out;                  // 4. Multiply-Accumulate (MAC) Matrix Loop
                3'b100: begin                                  // 5. Arithmetic Accumulate Vector
                            accum_reg <= accum_reg + A;
                            Out       <= accum_reg + A;
                        end
                3'b101: Out <= (A * B) + (C * B);              // 6. Dot Product Engine Matrix Row
                3'b110: Out <= (A << 4) + (B >>> 2);           // 7. Vector Scaling Arithmetic Shift (Barrel Shift)
                3'b111: Out <= (A ^ B) | C;                    // 8. Bitwise Logic Engine Operations
                default: Out <= 32'h0;
            endcase
        end
    end
endmodule
