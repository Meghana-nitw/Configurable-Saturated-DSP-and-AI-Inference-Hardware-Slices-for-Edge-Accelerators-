`timescale 1ns/1ps

module tb_dsp_slice; 
    // Clock and Reset Stimuli
    reg clk; 
    reg rst_n; 
    
    // UUT Input Pins 
    reg [2:0] dsp_opcode; 
    reg signed [15:0] dsp_A, dsp_B, dsp_C; 
    
    // UUT Output Observation Hook
    wire signed [31:0] dsp_out; 

    // Unit Under Test (UUT) Block Allocation
    dsp_slice u_dsp_inst ( 
        .clk(clk), 
        .rst_n(rst_n), 
        .opcode(dsp_opcode), 
        .A(dsp_A), 
        .B(dsp_B), 
        .C(dsp_C), 
        .Out(dsp_out) 
    ); 

    // Continuous 50MHz Clock Generation (Period = 20ns)
    always #10 clk = ~clk; 

    initial begin
        // Initialize Signals and Hold Reset 
        clk = 0; 
        rst_n = 0; 
        dsp_opcode = 3'b000; 
        dsp_A = 0; 
        dsp_B = 0; 
        dsp_C = 0; 
        
        // Release System Reset
        #25 rst_n = 1; 
        #15; 

        // ========================================================
        // DSP TEST ENGINE VERIFICATION MATRIX
        // ========================================================
        
        // Op 000: Multi-Input Addition (100 + 200 + 300 = 600)
        dsp_A = 16'd100; dsp_B = 16'd200; dsp_C = 16'd300; dsp_opcode = 3'b000; #20; 
        
        // Op 001: Multi-Input Subtraction (1000 - 400 - 100 = 500) 
        dsp_A = 16'd1000; dsp_B = 16'd400; dsp_C = 16'd100; dsp_opcode = 3'b001; #20; 
        
        // Op 010: Vector Multiplication (-25 * 4 = -100) 
        dsp_A = -16'd25; dsp_B = 16'd4; dsp_opcode = 3'b010; #20; 
        
        // Op 011: MAC Pipeline Sequential Accumulations
        dsp_opcode = 3'b011; dsp_A = 16'd5; dsp_B = 16'd6; #20; // 30 -> Accumulator
        dsp_A = 16'd10; dsp_B = 16'd2; #20;                     // 20 -> 30 + 20 = 50 
        
        // Op 100: Arithmetic Accumulator Stream Loops
        dsp_opcode = 3'b100; dsp_A = 16'd15; #20; 
        dsp_A = 16'd35; #20; 
        
        // Op 101: Combined Matrix Row Dot Product [(8*10) + (2*10) = 100] 
        dsp_A = 16'd8; dsp_B = 16'd10; dsp_C = 16'd2; dsp_opcode = 3'b101; #20; 
        
        // Op 110: Shift Engine Barrel Scale (A<<4 + B>>>2) -> (16<<4 + 40>>>2) = 256 + 10 = 266 
        dsp_A = 16'd16; dsp_B = 16'd40; dsp_opcode = 3'b110; #20; 
        
        // Op 111: Bitwise Logics (A^B | C) 
        dsp_A = 16'h00FF; dsp_B = 16'h0F0F; dsp_C = 16'hF000; dsp_opcode = 3'b111; #20; 
        
        #40;
        $finish; 
    end 
endmodule
