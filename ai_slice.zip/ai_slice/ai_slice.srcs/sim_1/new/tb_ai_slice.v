`timescale 1ns/1ps

module tb_ai_slice; 
    reg clk; 
    reg rst_n; 
    reg [1:0] ai_opcode; 
    reg signed [15:0] ai_in0, ai_in1, ai_in2, ai_in3; 
    reg signed [15:0] ai_w0, ai_w1, ai_w2, ai_w3; 
    reg signed [15:0] ai_scale, ai_bias; 
    wire signed [31:0] ai_out; 

    ai_slice u_ai_inst ( 
        .clk(clk), .rst_n(rst_n), .opcode(ai_opcode), 
        .in0(ai_in0), .in1(ai_in1), .in2(ai_in2), .in3(ai_in3), 
        .w0(ai_w0), .w1(ai_w1), .w2(ai_w2), .w3(ai_w3), 
        .bn_scale(ai_scale), .bn_bias(ai_bias), .Out(ai_out) 
    ); 

    always #10 clk = ~clk; 

    initial begin
        clk = 0; rst_n = 0; 
        ai_opcode = 2'b00; ai_in0 = 0; ai_in1 = 0; ai_in2 = 0; ai_in3 = 0; 
        ai_w0 = 0; ai_w1 = 0; ai_w2 = 0; ai_w3 = 0; ai_scale = 0; ai_bias = 0; 

        #25 rst_n = 1; #15; 

        ai_in0 = 16'd10; ai_in1 = 16'd20; ai_in2 = -16'd30; ai_in3 = 16'd40; 
        ai_w0 = 16'd2; ai_w1 = 16'd1; ai_w2 = 16'd0; ai_w3 = -16'd1; 
        
        ai_opcode = 2'b00; #20; 
        ai_opcode = 2'b01; #20; 
        ai_opcode = 2'b10; #20; 
        
        ai_scale = 16'h0; ai_bias = 16'h0; ai_in0 = -16'd16; ai_opcode = 2'b11; #20; 
        
        ai_in0 = 16'd5; ai_scale = 16'd2; ai_bias = 16'd1000; ai_opcode = 2'b11; #20; 
        
        #40;
        $finish; 
    end 
endmodule
