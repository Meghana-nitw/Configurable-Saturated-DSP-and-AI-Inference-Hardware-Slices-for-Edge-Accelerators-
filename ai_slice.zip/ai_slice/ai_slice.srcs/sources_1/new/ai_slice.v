`timescale 1ns/1ps

module ai_slice ( 
    input clk, 
    input rst_n, 
    input [1:0] opcode,
    input signed [15:0] in0, input signed [15:0] in1, 
    input signed [15:0] in2, input signed [15:0] in3, 
    input signed [15:0] w0, input signed [15:0] w1, 
    input signed [15:0] w2, input signed [15:0] w3, 
    input signed [15:0] bn_scale, 
    input signed [15:0] bn_bias, 
    output reg signed [31:0] Out 
); 

    wire signed [31:0] comp_max01, comp_max23; 
    wire signed [31:0] summation_network;
    wire signed [31:0] leaky_relu_scaled; 
    wire signed [31:0] batch_norm_out; 

    assign comp_max01 = (in0 > in1) ? in0 : in1; 
    assign comp_max23 = (in2 > in3) ? in2 : in3; 
    
    assign summation_network = in0 + in1 + in2 + in3;
    
    assign leaky_relu_scaled = (in0 < 0) ? ({{16{in0}}, in0} >>> 3) : {{16{in0}}, in0}; 
    
    assign batch_norm_out = (in0 * bn_scale) + {{16{bn_bias}}, 16'h0}; 

    always @(posedge clk or negedge rst_n) begin 
        if (!rst_n) begin 
            Out <= 32'h0; 
        end else begin 
            case (opcode) 
                2'b00: Out <= (in0 * w0) + (in1 * w1) + (in2 * w2) + (in3 * w3);
                2'b01: Out <= (comp_max01 > comp_max23) ? comp_max01 : comp_max23;
                2'b10: Out <= summation_network >>> 2;
                2'b11: Out <= (bn_scale != 0) ? batch_norm_out : leaky_relu_scaled;
                default: Out <= 32'h0; 
            endcase 
        end 
    end 
endmodule
